#include <userint.h>
//==============================================================================
//
// Title:		userFunc.c
// Purpose:		A short description of the implementation.
//
// Created on:	4/12/2018 at 3:27:13 PM by .
// Copyright:	. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files
#include "toolbox.h"
#include "userFunc.h"
#include "ATM_panel.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// Static global variables
   
//==============================================================================
// Static functions

//==============================================================================
// Global variables
   
   char *bal[5];
   int currentAmt=0;
   int sessionTime=0;
   int cardFlg=0;
   int fastCashFlg=0;
   int depositFlg=0;
   int withDrawFlg=0;
   int menuFlg=0;
   int writeFlg=0;
   long strLen=0;
   long position=0;
   long len=0;
   
//==============================================================================
// Global functions

/// HIFN  What does your function do?
/// HIPAR x/What inputs does your function expect?
/// HIRET What does your function return?

struct data
{ 
	char record[200];

} ;        
 struct data mydata[6]; 

 
   int Define_Your_Functions_Here (int x)
{
	return x;
}


int inits()
{
	int error = 0;
		writeFlg=0;
		currentAmt=0;
    	sessionTime=0;
    	cardFlg=0;
    	fastCashFlg=0;
   		depositFlg=0;
   		withDrawFlg=0;
   		menuFlg=0;
   		writeFlg=0;
   		strLen=0;
   		position=0;
   		len=0;
	
	       		/* Card Insert Button controls */
	errChk(SetCtrlVal(panelHandle,PANEL_CARD_BTTN,0));
	errChk(SetCtrlAttribute(panelHandle,PANEL_CARD_BTTN,ATTR_DIMMED,0));
	
				/* User Input and Enter controls */
		   				disableUserIn();
						
			 /* Left  Menu Value controls */
			 
	errChk(ResetTextBox(panelHandle,PANEL_MENU_LT_1,""));
	errChk(ResetTextBox(panelHandle,PANEL_MENU_LT_2,""));
	errChk(ResetTextBox(panelHandle,PANEL_MENU_LT_3,""));

	 		/* Right Menu Value controls */
	errChk(ResetTextBox(panelHandle,PANEL_MENU_RT_1,""));
	errChk(ResetTextBox(panelHandle,PANEL_MENU_RT_2,""));
	errChk(ResetTextBox(panelHandle,PANEL_MENU_RT_3,""));
 	
            	/* Left  Menu and Buttons controls */
	errChk(SetCtrlAttribute(panelHandle,PANEL_MENU_LT_1,ATTR_DIMMED,1));
	errChk(SetCtrlAttribute(panelHandle,PANEL_MENU_LT_2,ATTR_DIMMED,1));
	errChk(SetCtrlAttribute(panelHandle,PANEL_MENU_LT_3,ATTR_DIMMED,1));
	errChk(SetCtrlAttribute(panelHandle,PANEL_BTTN_LT_1,ATTR_DIMMED,1));
	errChk(SetCtrlAttribute(panelHandle,PANEL_BTTN_LT_2,ATTR_DIMMED,1));
	errChk(SetCtrlAttribute(panelHandle,PANEL_BTTN_LT_3,ATTR_DIMMED,1));
	
				/* Right Menu and Buttons controls */
	errChk(SetCtrlAttribute(panelHandle,PANEL_MENU_RT_1,ATTR_DIMMED,1));
	errChk(SetCtrlAttribute(panelHandle,PANEL_MENU_RT_2,ATTR_DIMMED,1));
	errChk(SetCtrlAttribute(panelHandle,PANEL_MENU_RT_3,ATTR_DIMMED,1));
	errChk(SetCtrlAttribute(panelHandle,PANEL_BTTN_RT_1,ATTR_DIMMED,1));
	errChk(SetCtrlAttribute(panelHandle,PANEL_BTTN_RT_2,ATTR_DIMMED,1));
	errChk(SetCtrlAttribute(panelHandle,PANEL_BTTN_RT_3,ATTR_DIMMED,1));
	

	
					/* Timer controls */
	sessionTime=0;
	errChk(SetCtrlAttribute(panelHandle,PANEL_TIMERC,ATTR_ENABLED,0));
	errChk(display("Welcome to Acme Bank.\nPlease insert your card\nand enter your account \nnumber in the User Input.\n\n\nPress Enter (E) when done.")); 
	
Error:
	
	return error;
}


int enableMenu()
{
	 int error = 0;
	 	
	char *mainMsg=(char*)malloc(150 * (sizeof(char)));
	sprintf(mainMsg,"Welcome to Acme Bank \n%s,%s \n\nPlease select transaction\nby using the buttons.",bal[1],bal[2]);	

	
	 /* Left  Menu and Buttons Attribute controls */
	errChk(SetCtrlAttribute(panelHandle,PANEL_MENU_LT_1,ATTR_DIMMED,0));
	errChk(SetCtrlAttribute(panelHandle,PANEL_MENU_LT_2,ATTR_DIMMED,0));
	errChk(SetCtrlAttribute(panelHandle,PANEL_MENU_LT_3,ATTR_DIMMED,0));
	errChk(SetCtrlAttribute(panelHandle,PANEL_BTTN_LT_1,ATTR_DIMMED,0));
	errChk(SetCtrlAttribute(panelHandle,PANEL_BTTN_LT_2,ATTR_DIMMED,0));
	errChk(SetCtrlAttribute(panelHandle,PANEL_BTTN_LT_3,ATTR_DIMMED,0));
	
		/* Right Menu and Buttons Attribute controls */
	errChk(SetCtrlAttribute(panelHandle,PANEL_MENU_RT_1,ATTR_DIMMED,0));
	errChk(SetCtrlAttribute(panelHandle,PANEL_MENU_RT_2,ATTR_DIMMED,0));
	errChk(SetCtrlAttribute(panelHandle,PANEL_MENU_RT_3,ATTR_DIMMED,0));
	errChk(SetCtrlAttribute(panelHandle,PANEL_BTTN_RT_1,ATTR_DIMMED,0));
	errChk(SetCtrlAttribute(panelHandle,PANEL_BTTN_RT_2,ATTR_DIMMED,0));
	errChk(SetCtrlAttribute(panelHandle,PANEL_BTTN_RT_3,ATTR_DIMMED,0));
	
	            /* Left  Menu Value controls */
	errChk(SetCtrlVal(panelHandle,PANEL_MENU_LT_1,"None"));
	errChk(SetCtrlVal(panelHandle,PANEL_MENU_LT_2,"Balance\nInquiry"));
	errChk(SetCtrlVal(panelHandle,PANEL_MENU_LT_3," Return card\n & Terminate "));

	 		/* Right Menu Value controls */
	errChk(SetCtrlVal(panelHandle,PANEL_MENU_RT_1,"Deposit"));
	errChk(SetCtrlVal(panelHandle,PANEL_MENU_RT_2,"Withdraw"));
	errChk(SetCtrlVal(panelHandle,PANEL_MENU_RT_3,"Fast Cash\n$50"));
	errChk(display(mainMsg));
    free(mainMsg);
	sessionTime=0;
	menuFlg=0;
Error:
	
	return error;

}

int enableUserIn()
{
	int error = 0; 
  	errChk(SetCtrlVal(panelHandle,PANEL_USER_INPUT,""));
	errChk(SetCtrlAttribute(panelHandle,PANEL_USER_INPUT,ATTR_DIMMED,0));
	errChk(SetCtrlAttribute(panelHandle,PANEL_ENTER,ATTR_DIMMED,0));
	Error:
	
	return error;

}

int disableUserIn()
{
	int error = 0; 
   	errChk(SetCtrlVal(panelHandle,PANEL_USER_INPUT,""));
	errChk(SetCtrlAttribute(panelHandle,PANEL_USER_INPUT,ATTR_DIMMED,1));
	errChk(SetCtrlAttribute(panelHandle,PANEL_ENTER,ATTR_DIMMED,1));
  Error:
	
	return error;

}

int display(char *displayMsg)
{
	 int error = 0;
	 errChk(ResetTextBox(panelHandle,PANEL_DISPLAY_BOX,""));
	 errChk(SetCtrlVal(panelHandle,PANEL_DISPLAY_BOX,displayMsg));

Error:
	
	return error;

}

int timerFunc()
{
	int error=0;

	++sessionTime;
	if(sessionTime>=10)
	{
	    inits(); 
		errChk(display("\nYour session has been terminated \ndue to inactivity or menu selection. \nPlease take your car \n\nGoodbye!"));
	  
	}

Error:
	
	return error;
}




int writeFile()
{
	int error=0;
	char writeBuff[100];
   	char pathname[MAX_PATHNAME_LEN];
	char dirname[MAX_PATHNAME_LEN];
	errChk(GetProjectDir(dirname));
	errChk(MakePathname(dirname,"Accounts.txt",pathname));
	FILE *fp = fopen("Accounts.txt","r+") ;
	fseek(fp,strLen,SEEK_SET);
	
	for(int l=0;l<len;l++)
		fputc(' ',fp);
	
	fseek(fp,strLen,SEEK_SET); 
	sprintf(writeBuff,"%s,%s,%s,%s\n",bal[0],bal[1],bal[2],bal[3]);
	fputs(writeBuff,fp);
	fclose(fp);
	writeFlg=1;
Error:
	
	return error;

}




int balInqFunc()
{
	int error=0;
  	sessionTime=0;
  	char *InqMsg=(char*)malloc(30 * (sizeof(char))); 
  		sprintf(InqMsg,"Your Balance Is:\n$ %s",bal[3]);
		errChk(display(InqMsg));
		free(InqMsg);
Error:
	
	return error;

}


int returnCardFunc()
{
	int error=0;
 	errChk(inits()); 
 	errChk(display("\nYour session has been terminated \ndue to inactivity or menu selection. \nPlease take your car \n\nGoodbye!"));

Error:
	
	return error;
}


int depositeFunc()
{   
	int error=0;
    char depDrwBuf[50];
	char depAmount[50];
    int deposdAmt=0;
	 
	errChk(GetCtrlVal(panelHandle,PANEL_USER_INPUT,depDrwBuf)); 
	deposdAmt= atoi(depDrwBuf);
	currentAmt += deposdAmt;
	sprintf(bal[3],"%d",currentAmt);
	errChk(writeFile()); 
	sprintf(depAmount," $( %s ) Deposited",depDrwBuf);
	errChk(display(depAmount));



Error:	
	 return error;

}
int withdrawFunc()
{
	int error=0;
    char withdrwBuf[50];
	char printBuff[50];
    int withdrwAmt=0;
    
       
   	errChk(GetCtrlVal(panelHandle,PANEL_USER_INPUT,withdrwBuf)); 
   	withdrwAmt= atoi(withdrwBuf);
    if(currentAmt >= withdrwAmt)
	{
		currentAmt-=withdrwAmt;
		sprintf(bal[3],"%d",currentAmt); 
		writeFile();
		sprintf(printBuff,"$( %d ) Withdrawn",withdrwAmt);
		errChk(SetCtrlVal(panelHandle,PANEL_USER_INPUT,""));
	    errChk(display(printBuff));
	}
	else
	
	{
		
	  errChk(display("Insufficient funds in account \nPlease check your balance\n and try again"));
	
	}
   
   

Error:
	
	return error;
}
int fastChashFunc()
{
 
     int error=0,fstCshAmt=50;
     if(currentAmt>=50)
	 {
	     		currentAmt-=fstCshAmt;
		sprintf(bal[3],"%d",currentAmt); 
		errChk(writeFile());
	
		errChk(display("\n\n$(50) Withdrawn"));
	 
	 }
	 else
	 {
		errChk(ResetTextBox(panelHandle,PANEL_DISPLAY_BOX,""));
		errChk(display("Insufficient funds in account \nPlease check your balance\nand try again"));
	
	
	  }
   
	
Error:
	
	return error;
}


int readF(char *cmpstr)
{
	
  	const char token[2] = ",";
  	char *balance;
	int error=0;
	int k=0,i=0,lineNum=0,findStr=0; 
	char pathname[MAX_PATHNAME_LEN];
	char dirname[MAX_PATHNAME_LEN];
	errChk(GetProjectDir(dirname));
	errChk(MakePathname(dirname,"Accounts.txt",pathname));

	FILE *fp = fopen("Accounts.txt", "r") ;
	
	
	while( fscanf(fp,"%s \n", mydata[i].record ) !=EOF) 
	{	   
		if( ( strstr(mydata[i].record,cmpstr)!=NULL ) ) 
		{
		position=ftell(fp);
		len=strlen( mydata[i].record );
		strLen=position-(len+2);
		if(strLen<0)strLen=0;
		findStr++;
		lineNum=i;
		}
		 i++;
	}
	

 
  	 if(findStr)
	 {  
	 	cardFlg=0;
		sessionTime=0;
		errChk(ResetTextBox(panelHandle,PANEL_DISPLAY_BOX,""));
		errChk(display("\nverified account"));
		balance = strtok (mydata[lineNum].record,token);
  		bal[k]=balance;k++;
  		while (balance != NULL)
  		{
   			balance = strtok (NULL,token);
			bal[k]=balance;

			if(balance!= NULL)
			{
				 bal[k]=balance;
				 if(k==3)
					 currentAmt=atoi(bal[k]);
				  k++;
			}	
		
  		}
		menuFlg=1;	  
	 }
	 else
	 {
	 	 cardFlg=1;
		 sessionTime=0;
		 errChk(ResetTextBox(panelHandle,PANEL_DISPLAY_BOX,""));
		 errChk(display("Account Verification Failed Message\n\n re-enter Account Number\n"));
		
	 }


 
          
Error:
	
	return error;   
  
}

int userInput()
{
   
    char buff[10];
    int error=0;
    errChk(GetCtrlVal(panelHandle,PANEL_USER_INPUT,buff));
   	errChk(SetCtrlVal(panelHandle,PANEL_USER_INPUT,""));
	if(strlen(buff)==5)
	{

		sessionTime=0;
		errChk(readF(buff));
	}
	else
	{
		cardFlg=1;
		errChk(ResetTextBox(panelHandle,PANEL_DISPLAY_BOX,""));
		errChk(display("\n\ninvalid account"));
		
	}

Error:
	
	return error;
}


 int insCardFunc()
{
	int error=0; 
	static int cardBttnVal=0;
	errChk(GetCtrlVal(panelHandle,PANEL_CARD_BTTN,&cardBttnVal));
	if(cardBttnVal ||withDrawFlg||depositFlg)
	{
			cardFlg=1;
			errChk(SetCtrlAttribute(panelHandle,PANEL_USER_INPUT,ATTR_DIMMED,0));
			errChk(SetCtrlAttribute(panelHandle,PANEL_ENTER,ATTR_DIMMED,0));
			errChk(SetCtrlAttribute(panelHandle,PANEL_TIMERC,ATTR_ENABLED,1));
			errChk(SetCtrlAttribute(panelHandle,PANEL_CARD_BTTN,ATTR_DIMMED,1));

	}
	else
	{
	    cardFlg=0; 
		errChk(SetCtrlVal(panelHandle,PANEL_DISPLAY_BOX,"\nYour session has been terminated \ndue to inactivity or menu selection.\nPlease take your car \n\nGoodbye!")); 
	    errChk(inits()); 
	}
Error:
	
	return error;
}


int enterFunc()
{
	int error=0;
	sessionTime=0;
	 if(cardFlg==1)
	 {
	   errChk(userInput());
	   if(menuFlg==1)
	   {
		   errChk(disableUserIn());
		   errChk(enableMenu());
	   }
	 
	 
	 }
	 else if(withDrawFlg==1)
	 {
	    withDrawFlg=0;
	 	errChk(withdrawFunc());
		if(writeFlg==1)
		{
			errChk(disableUserIn());
		}
	 
	 }
	  else if(depositFlg==1) 
	  {
	  	   depositFlg=0;
	  	   errChk(depositeFunc());
		   if(writeFlg==1)
		   {
			   errChk(disableUserIn());
		   }
	  
	  }

Error:
	
	return error;

}



